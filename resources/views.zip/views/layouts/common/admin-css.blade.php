<!-- Fonts -->
<link rel="dns-prefetch" href="//fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
<!-- Styles -->
<!--<link rel="icon" type="image/x-icon" href="https://abeerjaipur.com/assets/img/logo.png"/>-->
<!--<link rel="icon" href="https://abeerjaipur.com/assets/img/logo.png" type="image/png" sizes="16x16">-->
<link rel="icon" type="image/x-icon" href="https://abeerjaipur.com/frontend/webimages/logo.png"/>
<link rel="icon" href="https://abeerjaipur.com/frontend/webimages/logo.png" type="image/png" sizes="16x16">
<link rel="stylesheet" href="{{url('public/admin')}}/css/pace.css">
<!--vendors-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="{{url('public/admin')}}/css/bootstrap-datepicker3.min.css">
<link rel="stylesheet" type="text/css" href="{{url('public/admin')}}/css/jquery.scrollbar.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="{{url('public/admin')}}/css/select2.min.css">
<link rel="stylesheet" href="{{url('public/admin')}}/css/jquery-ui.min.css">
<link rel="stylesheet" href="{{url('public/admin')}}/css/daterangepicker.css">
<link rel="stylesheet" href="{{url('public/admin')}}/css/bootstrap-timepicker.min.css">
<link href="https://fonts.googleapis.com/css?family=Hind+Vadodara:400,500,600" rel="stylesheet">
<link rel="stylesheet" href="{{url('public')}}/fonts/jost/jost.css">
<!--Material Icons-->
<link rel="stylesheet" type="text/css" href="{{url('public')}}/fonts/materialdesignicons/materialdesignicons.min.css">
<!--Bootstrap + atmos Admin CSS-->
<link rel="stylesheet" type="text/css" href="{{url('public/admin')}}/css/atmos.min.css">
<link rel="stylesheet" type="text/css" href="{{url('public/admin')}}/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="{{url('public/admin')}}/css/custom.css">
<!-- Additional library for page -->
<link rel="stylesheet" href="{{url('public/css/sweetalert.css')}}" type="text/css" />
