<script src="{{url('public/admin')}}/js/jquery.min.js"></script>
<script src="{{url('public/admin')}}/js/pace.min.js"></script>
<script src="{{url('public/admin')}}/js/jquery-ui.min.js"></script>
<!-- <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script> -->
<script src="{{url('public/admin')}}/js/popper.js"></script>
<script src="{{url('public/admin')}}/js/bootstrap.min.js"></script>
<script src="{{url('public/admin')}}/js/select2.full.min.js"></script>
<script src="{{url('public/admin')}}/js/jquery.scrollbar.min.js"></script>
<script src="{{url('public/admin')}}/js/listjs.min.js"></script>
<script src="{{url('public/admin')}}/js/moment.min.js"></script>
<script src="{{url('public/admin')}}/js/daterangepicker.js"></script>
<script src="{{url('public/admin')}}/js/bootstrap-datepicker.min.js"></script>
<script src="{{url('public/admin')}}/js/bootstrap-notify.min.js"></script>
<script src="{{url('public/admin')}}/js/atmos.min.js"></script>
<script src="{{url('public/admin')}}/js/apexcharts.min.js"></script>
<script src="{{url('public/admin')}}/js/dashboard-01.js"></script>
<script src="{{url('public/admin')}}/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="{{url('public/js/sweetalert.js')}}"></script>
